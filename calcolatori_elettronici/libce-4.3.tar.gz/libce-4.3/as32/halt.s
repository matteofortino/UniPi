.global halt
halt:
	hlt
